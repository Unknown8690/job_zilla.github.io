<?php 

$this->load->view('EMP/headerfiles/Dash_header.php');
$this->load->view('EMP/master_files');
$this->load->view($main);
$this->load->view('EMP/footerfiles/Dash_footer.php');

?>